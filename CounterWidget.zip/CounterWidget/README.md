# 📱 Tageszähler Widget

Ein Android Home-Screen-Widget mit täglichem Countdown – startet bei 20, jeder Tipp zählt runter, Mitternacht-Reset mit automatischem Speichern.

---

## ✨ Funktionen

- **Widget**: Zeigt den aktuellen Zähler (0–20) auf dem Homescreen
- **Tippen = −1**: Einmal aufs Widget tippen → Zähler geht um 1 runter
- **Mitternacht-Reset**: Um 00:00 Uhr wird der Endstand gespeichert, Zähler startet wieder bei 20
- **Farbskala**:
  - 🟢 Grün: 16–20 (viel übrig)
  - 🟡 Gelb: 9–15
  - 🟠 Orange: 4–8
  - 🔴 Rot: 0–3 (knapp!)
- **Hauptapp**: Zeigt alle Tagesabschlüsse der letzten Tage mit Datum, Endstand und Balken

---

## 🛠️ Installation

### Voraussetzungen
- Android Studio (Hedgehog oder neuer)
- Android SDK 26+
- Kotlin Plugin

### Schritte

1. **Projekt öffnen**
   ```
   Android Studio → Open → CounterWidget/
   ```

2. **Gradle synchronisieren**
   - Android Studio erkennt das Projekt automatisch
   - `Sync Now` klicken wenn gefragt

3. **App installieren**
   - Gerät per USB verbinden (USB-Debugging aktivieren)
   - Oder einen Emulator starten (API 26+)
   - ▶️ Run-Button drücken

4. **Widget zum Homescreen hinzufügen**
   - Homescreen lange drücken → Widgets
   - "Tageszähler" suchen
   - Widget platzieren (mindestens 2×2 Zellen)

---

## 📂 Projektstruktur

```
app/src/main/
├── java/com/counter/widget/
│   ├── CounterWidget.kt        # Widget Provider (BroadcastReceiver)
│   ├── CounterStorage.kt       # SharedPreferences Datenspeicherung
│   ├── MainActivity.kt         # Hauptapp + History RecyclerView
│   ├── MidnightResetReceiver.kt # Alarm um Mitternacht
│   └── BootReceiver.kt         # Alarm nach Neustart wiederherstellen
├── res/
│   ├── layout/
│   │   ├── widget_counter.xml  # Widget-Layout
│   │   ├── activity_main.xml   # Hauptapp-Layout
│   │   └── item_history.xml    # Listeneintrag Layout
│   ├── xml/
│   │   └── counter_widget_info.xml  # Widget-Metadaten
│   └── values/
│       ├── colors.xml
│       ├── strings.xml
│       └── themes.xml
└── AndroidManifest.xml
```

---

## ⚙️ Wie es funktioniert

### Datenspeicherung
- Aktueller Zählerstand: `SharedPreferences` → Key `current_count`
- Tagesabschlüsse: `SharedPreferences` → Keys `history_2025-01-15` etc.

### Mitternacht-Reset
- Beim ersten App-Start (und nach jedem Geräte-Neustart) wird ein `AlarmManager.setExactAndAllowWhileIdle()` Alarm auf 00:00 Uhr gesetzt
- `MidnightResetReceiver` speichert den Tagesabschluss und setzt den Zähler auf 20
- Danach wird der nächste Alarm für die folgende Nacht gesetzt

### Widget-Updates
- Jeder Tipp sendet einen `ACTION_DECREASE` Broadcast
- `CounterWidget.onReceive()` verarbeitet ihn, speichert den neuen Stand und aktualisiert alle Widget-Instanzen

---

## 🔑 Benötigte Berechtigungen

| Permission | Grund |
|---|---|
| `RECEIVE_BOOT_COMPLETED` | Alarm nach Neustart wiederherstellen |
| `USE_EXACT_ALARM` | Präziser Mitternacht-Reset |
| `SCHEDULE_EXACT_ALARM` | Fallback für ältere Android-Versionen |

---

## 💡 Tipps

- **Mehrere Widgets**: Du kannst das Widget mehrfach auf dem Homescreen platzieren – alle zeigen denselben Zähler
- **App öffnen**: Auf den kleinen "TIPPEN = −1" Text im Widget tippen öffnet die Hauptapp
- **Datum-Zeile**: Der Text in der App wird jedes Mal beim Öffnen aktualisiert
