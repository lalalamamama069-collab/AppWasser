package com.counter.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Re-schedule the midnight reset after device reboot
            MidnightResetReceiver.scheduleMidnightReset(context)
            // Refresh widgets
            CounterWidget.updateAllWidgets(context)
        }
    }
}
