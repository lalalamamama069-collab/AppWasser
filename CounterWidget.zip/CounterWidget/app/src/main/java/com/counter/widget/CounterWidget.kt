package com.counter.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class CounterWidget : AppWidgetProvider() {

    companion object {
        const val ACTION_DECREASE = "com.counter.widget.ACTION_DECREASE"

        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, CounterWidget::class.java))
            val intent = Intent(context, CounterWidget::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            }
            context.sendBroadcast(intent)
        }
    }

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (widgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, widgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_DECREASE) {
            CounterStorage.decreaseCount(context)
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, CounterWidget::class.java))
            for (id in ids) {
                updateWidget(context, manager, id)
            }
        }
    }

    private fun updateWidget(
        context: Context,
        appWidgetManager: AppWidgetManager,
        widgetId: Int
    ) {
        val count = CounterStorage.getCurrentCount(context)
        val views = RemoteViews(context.packageName, R.layout.widget_counter)

        views.setTextViewText(R.id.tv_count, count.toString())

        // Color feedback based on count
        val colorRes = when {
            count > 15 -> R.color.count_high
            count > 8 -> R.color.count_mid
            count > 3 -> R.color.count_low
            else -> R.color.count_critical
        }
        views.setTextColor(R.id.tv_count, context.getColor(colorRes))

        // Tap to decrease
        val decreaseIntent = Intent(context, CounterWidget::class.java).apply {
            action = ACTION_DECREASE
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, 0, decreaseIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

        // Tap label opens app
        val appIntent = Intent(context, MainActivity::class.java)
        val appPending = PendingIntent.getActivity(
            context, 1, appIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.tv_label, appPending)

        appWidgetManager.updateAppWidget(widgetId, views)
    }
}
